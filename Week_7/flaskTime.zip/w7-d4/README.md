# mini-project-IV
#### This repo contains instruction for Mini Project IV!!

Welcome to the 4th Miniproject. We will, once again, practice supervised learning. In addition to previous tasks and challenges, we will deploy our solution to cloud as API service. We will practice following skills:

- Data Preparation
- Feature Engineering
- Supervised Learning
- Pipelines
- Model Persistance
- Flask - building own API
- Deployment to Cloud (AWS)

Go to the notebook mini-project-IV.ipynb where you can find all instructions.
**Enjoy!!!**


